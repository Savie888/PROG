import java.util.Scanner;

public class JavaJeepsSimulation {
    private static final int MAX_TRUCKS = 10; // max 
    private CoffeeTruck[] trucks; // object array 
    private int truckCount; // starts from 0
    private Scanner scanner;
    
    public JavaJeepsSimulation() {
        trucks = new CoffeeTruck[MAX_TRUCKS];
        truckCount = 0;
        scanner = new Scanner(System.in);
    }
    
    public void run() {
        System.out.println("=== JAVAJEEPS Coffee Truck Business Simulation ===");
        
        while (true) {
            displayMainMenu();
            int choice = getIntInput();
            
            switch (choice) {
                case 1:
                    createCoffeeTruck();
                    break;
                case 2:
                    simulateTruckFeatures();
                    break;
                case 3:
                    showDashboard();
                    break;
                case 4:
                    System.out.println("Thank you for using JavaJeeps! Goodbye!");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
    
    private void displayMainMenu() {
        System.out.println("\n=== MAIN MENU ===");
        System.out.println("1. Create a Coffee Truck");
        System.out.println("2. Simulate Coffee Truck Features");
        System.out.println("3. Dashboard");
        System.out.println("4. Exit");
        System.out.print("Enter your choice: ");
    }
    
    private void createCoffeeTruck() {
        if (truckCount >= MAX_TRUCKS) {
            System.out.println("Maximum number of trucks reached!"); 
            return;
        }
        
        System.out.println("\n=== CREATE COFFEE TRUCK ===");
        System.out.println("1. Regular Coffee Truck (JavaJeep)");
        System.out.println("2. Special Coffee Truck (JavaJeep+)");
        System.out.print("Enter truck type: ");
        
        int type = getIntInput();
        System.out.print("Enter truck location: ");
        scanner.nextLine(); // consume newline
        String location = scanner.nextLine();
        
        // Check if location is already taken
        for (int i = 0; i < truckCount; i++) {
            if (trucks[i].getLocation().equalsIgnoreCase(location)) {
                System.out.println("Location already occupied by another truck!");
                return;
            }
        }
        
        CoffeeTruck truck;
        if (type == 1) {
            truck = new RegularCoffeeTruck(location);
        } else if (type == 2) {
            truck = new SpecialCoffeeTruck(location);
        } else {
            System.out.println("Invalid truck type!");
            return;
        }
        
        // Initial loadout
        performInitialLoadout(truck);
        
        trucks[truckCount] = truck;
        truckCount++;
        
        System.out.println("Coffee truck created successfully at " + location + "!");
    }
    
    private void performInitialLoadout(CoffeeTruck truck) {
        System.out.println("\n=== INITIAL LOADOUT ===");
        System.out.println("Configure your truck's storage bins:");
        
        for (int i = 0; i < truck.getStorageBins().length; i++) {
            System.out.println("\nBin " + (i + 1) + ":");
            System.out.println("1. Small Cup  2. Medium Cup  3. Large Cup");
            System.out.println("4. Coffee Beans  5. Milk  6. Water");
            if (truck instanceof SpecialCoffeeTruck && i >= 8) {
                System.out.println("7. Syrup Add-on");
            }
            System.out.print("Select item type: ");
            
            int itemType = getIntInput();
            System.out.print("Enter quantity: ");
            int quantity = getIntInput();
            
            Item item = createItem(itemType, quantity, truck instanceof SpecialCoffeeTruck && i >= 8);
            if (item != null) {
                truck.getStorageBins()[i].addItem(item, quantity);
            }
        }
        
        // Set prices
        setPrices(truck);
    }
    
    private Item createItem(int type, int quantity, boolean isSyrupBin) {
        switch (type) {
            case 1: return new Cup("Small", 8.0);
            case 2: return new Cup("Medium", 12.0);
            case 3: return new Cup("Large", 16.0);
            case 4: return new Ingredient("Coffee Beans", "grams");
            case 5: return new Ingredient("Milk", "fl oz");
            case 6: return new Ingredient("Water", "fl oz");
            case 7:
                if (isSyrupBin) {
                    System.out.print("Enter syrup flavor: ");
                    scanner.nextLine(); // consume newline
                    String flavor = scanner.nextLine();
                    return new Ingredient(flavor + " Syrup", "fl oz");
                }
                break;
        }
        System.out.println("Invalid item type!");
        return null;
    }
    
    private void setPrices(CoffeeTruck truck) {
        System.out.println("\n=== SET PRICES ===");
        System.out.print("Small Americano price: $");
        truck.getPriceList().setPrice("Small Americano", getDoubleInput());
        System.out.print("Medium Americano price: $");
        truck.getPriceList().setPrice("Medium Americano", getDoubleInput());
        System.out.print("Large Americano price: $");
        truck.getPriceList().setPrice("Large Americano", getDoubleInput());
        
        System.out.print("Small Latte price: $");
        truck.getPriceList().setPrice("Small Latte", getDoubleInput());
        System.out.print("Medium Latte price: $");
        truck.getPriceList().setPrice("Medium Latte", getDoubleInput());
        System.out.print("Large Latte price: $");
        truck.getPriceList().setPrice("Large Latte", getDoubleInput());
        
        System.out.print("Small Cappuccino price: $");
        truck.getPriceList().setPrice("Small Cappuccino", getDoubleInput());
        System.out.print("Medium Cappuccino price: $");
        truck.getPriceList().setPrice("Medium Cappuccino", getDoubleInput());
        System.out.print("Large Cappuccino price: $");
        truck.getPriceList().setPrice("Large Cappuccino", getDoubleInput());
        
        if (truck instanceof SpecialCoffeeTruck) {
            System.out.print("Extra shot price: $");
            truck.getPriceList().setPrice("Extra Shot", getDoubleInput());
            System.out.print("Syrup add-on price: $");
            truck.getPriceList().setPrice("Syrup Add-on", getDoubleInput());
        }
    }
    
    private void simulateTruckFeatures() {
        if (truckCount == 0) {
            System.out.println("No trucks available. Please create a truck first.");
            return;
        }
        
        System.out.println("\n=== SELECT TRUCK ===");
        for (int i = 0; i < truckCount; i++) {
            System.out.println((i + 1) + ". " + trucks[i].getType() + " at " + trucks[i].getLocation());
        }
        System.out.print("Select truck: ");
        
        int truckIndex = getIntInput() - 1;
        if (truckIndex < 0 || truckIndex >= truckCount) {
            System.out.println("Invalid truck selection!");
            return;
        }
        
        CoffeeTruck selectedTruck = trucks[truckIndex];
        
        while (true) {
            System.out.println("\n=== TRUCK FEATURES ===");
            System.out.println("1. Make Coffee Sale");
            System.out.println("2. View Truck Information");
            System.out.println("3. Restock Storage Bins");
            System.out.println("4. Maintenance");
            System.out.println("5. Back to Main Menu");
            System.out.print("Enter choice: ");
            
            int choice = getIntInput();
            
            switch (choice) {
                case 1:
                    makeCoffeeSale(selectedTruck);
                    break;
                case 2:
                    viewTruckInformation(selectedTruck);
                    break;
                case 3:
                    restockStorageBins(selectedTruck);
                    break;
                case 4:
                    performMaintenance(selectedTruck);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice!");
            }
        }
    }
    
    private void makeCoffeeSale(CoffeeTruck truck) {
        System.out.println("\n=== MAKE COFFEE SALE ===");
        System.out.println("1. Americano  2. Latte  3. Cappuccino");
        System.out.print("Select drink type: ");
        int drinkType = getIntInput();
        
        System.out.println("1. Small  2. Medium  3. Large");
        System.out.print("Select size: ");
        int sizeType = getIntInput();
        
        String[] drinkNames = {"", "Americano", "Latte", "Cappuccino"};
        String[] sizes = {"", "Small", "Medium", "Large"};
        
        if (drinkType < 1 || drinkType > 3 || sizeType < 1 || sizeType > 3) {
            System.out.println("Invalid selection!");
            return;
        }
        
        String drinkName = drinkNames[drinkType];
        String size = sizes[sizeType];
        double cupSize = (sizeType == 1) ? 8.0 : (sizeType == 2) ? 12.0 : 16.0;
        
        CoffeeOrder order = new CoffeeOrder(drinkName, size, cupSize);
        
        // Special truck customizations
        if (truck instanceof SpecialCoffeeTruck) {
            System.out.println("Brew strength: 1. Light  2. Standard  3. Strong");
            System.out.print("Select brew strength: ");
            int brewStrength = getIntInput();
            order.setBrewStrength(brewStrength);
            
            System.out.print("Extra shots (0 for none): ");
            int extraShots = getIntInput();
            order.setExtraShots(extraShots);
            
            System.out.print("Add syrup? (y/n): ");
            scanner.nextLine(); // consume newline
            String addSyrup = scanner.nextLine();
            if (addSyrup.equalsIgnoreCase("y")) {
                order.setHasSyrup(true);
            }
        }
        
        // Process the order
        boolean success = truck.processOrder(order);
        if (success) {
            double price = truck.getPriceList().getPrice(size + " " + drinkName);
            if (truck instanceof SpecialCoffeeTruck) {
                if (order.getExtraShots() > 0) {
                    price += order.getExtraShots() * truck.getPriceList().getPrice("Extra Shot");
                }
                if (order.isHasSyrup()) {
                    price += truck.getPriceList().getPrice("Syrup Add-on");
                }
            }
            System.out.println("Total Price: $" + String.format("%.2f", price));
        } else {
            System.out.println("Order failed - insufficient ingredients!");
        }
    }
    
    private void viewTruckInformation(CoffeeTruck truck) {
        System.out.println("\n=== TRUCK INFORMATION ===");
        System.out.println("Type: " + truck.getType());
        System.out.println("Location: " + truck.getLocation());
        
        System.out.println("\n--- Storage Bins ---");
        StorageBin[] bins = truck.getStorageBins();
        for (int i = 0; i < bins.length; i++) {
            System.out.println("Bin " + (i + 1) + ": " + bins[i].getContents());
        }
        
        System.out.println("\n--- Menu & Prices ---");
        truck.getPriceList().displayMenu();
        
        System.out.println("\n--- Sales Transactions ---");
        truck.getSalesHistory().displayTransactions();
    }
    
    private void restockStorageBins(CoffeeTruck truck) { 
        System.out.println("\n=== RESTOCK STORAGE BINS ===");
        System.out.println("1. Add items to bin");
        System.out.println("2. Replace bin contents");
        System.out.println("3. Empty bin");
        System.out.print("Select action: ");
        
        int action = getIntInput();
        System.out.print("Select bin number (1-" + truck.getStorageBins().length + "): ");
        int binNumber = getIntInput() - 1;
        
        if (binNumber < 0 || binNumber >= truck.getStorageBins().length) {
            System.out.println("Invalid bin number!");
            return;
        }
        
        StorageBin bin = truck.getStorageBins()[binNumber];
        
        switch (action) {
            case 1:
                System.out.print("Enter quantity to add: ");
                int quantity = getIntInput();
                bin.addQuantity(quantity);
                System.out.println("Added " + quantity + " items to bin " + (binNumber + 1));
                break;
            case 2:
                System.out.println("Select new item type:");
                System.out.println("1. Small Cup  2. Medium Cup  3. Large Cup");
                System.out.println("4. Coffee Beans  5. Milk  6. Water");
                if (truck instanceof SpecialCoffeeTruck && binNumber >= 8) {
                    System.out.println("7. Syrup Add-on");
                }
                System.out.print("Select: ");
                int itemType = getIntInput();
                System.out.print("Enter quantity: ");
                quantity = getIntInput();
                
                Item newItem = createItem(itemType, quantity, truck instanceof SpecialCoffeeTruck && binNumber >= 8);
                if (newItem != null) {
                    bin.replaceContents(newItem, quantity);
                    System.out.println("Bin " + (binNumber + 1) + " contents replaced.");
                }
                break;
            case 3:
                bin.empty();
                System.out.println("Bin " + (binNumber + 1) + " emptied.");
                break;
            default:
                System.out.println("Invalid action!");
        }
    }
    
    private void performMaintenance(CoffeeTruck truck) {
        System.out.println("\n=== MAINTENANCE ===");
        System.out.println("1. Change truck location");
        System.out.println("2. Update prices");
        System.out.print("Select maintenance option: ");
        
        int option = getIntInput();
        
        switch (option) {
            case 1:
                System.out.print("Enter new location: ");
                scanner.nextLine(); 
                String newLocation = scanner.nextLine();
                
                for (int i = 0; i < truckCount; i++) {
                    if (trucks[i] != truck && trucks[i].getLocation().equalsIgnoreCase(newLocation)) {
                        System.out.println("Location already occupied!");
                        return;
                    }
                }
                
                truck.setLocation(newLocation);
                System.out.println("Location updated to: " + newLocation);
                break;
            case 2:
                setPrices(truck);
                System.out.println("Prices updated successfully!");
                break;
            default:
                System.out.println("Invalid option!");
        }
    }
    
    private void showDashboard() {
        System.out.println("\n=== DASHBOARD ===");
        
        int regularCount = 0;
        int specialCount = 0;
        
        for (int i = 0; i < truckCount; i++) {
            if (trucks[i] instanceof SpecialCoffeeTruck) {
                specialCount++;
            } else {
                regularCount++;
            }
        }
        
        System.out.println("Total Trucks Deployed: " + truckCount);
        System.out.println("  - Regular Trucks: " + regularCount);
        System.out.println("  - Special Trucks: " + specialCount);
        
        System.out.println("\n--- Aggregate Inventory ---");
        int[] cupCounts = new int[3]; // Small, Medium, Large
        double coffeeBeans = 0;
        double milk = 0;
        double water = 0;
        double syrups = 0;
        
        for (int i = 0; i < truckCount; i++) {
            StorageBin[] bins = trucks[i].getStorageBins();
            for (StorageBin bin : bins) {
                if (bin.getItem() != null) {
                    String itemName = bin.getItem().getName();
                    if (itemName.contains("Small Cup")) {
                        cupCounts[0] += bin.getQuantity();
                    } else if (itemName.contains("Medium Cup")) {
                        cupCounts[1] += bin.getQuantity();
                    } else if (itemName.contains("Large Cup")) {
                        cupCounts[2] += bin.getQuantity();
                    } else if (itemName.contains("Coffee Beans")) {
                        coffeeBeans += bin.getQuantity();
                    } else if (itemName.contains("Milk")) {
                        milk += bin.getQuantity();
                    } else if (itemName.contains("Water")) {
                        water += bin.getQuantity();
                    } else if (itemName.contains("Syrup")) {
                        syrups += bin.getQuantity();
                    }
                }
            }
        }
        
        System.out.println("Small Cups: " + cupCounts[0]);
        System.out.println("Medium Cups: " + cupCounts[1]);
        System.out.println("Large Cups: " + cupCounts[2]);
        System.out.println("Coffee Beans: " + coffeeBeans + " grams");
        System.out.println("Milk: " + milk + " fl oz");
        System.out.println("Water: " + water + " fl oz");
        System.out.println("Syrups: " + syrups + " fl oz");
        
        System.out.println("\n--- Combined Sales Summary ---");
        double totalSales = 0;
        int totalTransactions = 0;
        
        for (int i = 0; i < truckCount; i++) {
            totalSales += trucks[i].getSalesHistory().getTotalSales();
            totalTransactions += trucks[i].getSalesHistory().getTransactionCount();
        }
        
        System.out.println("Total Transactions: " + totalTransactions);
        System.out.println("Total Sales: $" + String.format("%.2f", totalSales));
    }
    
    private int getIntInput() {
        try {
            return scanner.nextInt();
        } catch (Exception e) {
            scanner.nextLine(); // clear buffer
            return -1;
        }
    }
    
    private double getDoubleInput() {
        try {
            return scanner.nextDouble();
        } catch (Exception e) {
            scanner.nextLine(); 
            return 0.0;
        }
    }
    
    public static void main(String[] args) {
        JavaJeepsSimulation simulation = new JavaJeepsSimulation();
        simulation.run();
    }
}