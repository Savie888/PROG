public class Ingredient extends Item {
    public Ingredient(String name, String unit) {
        super(name, unit);
    }
}