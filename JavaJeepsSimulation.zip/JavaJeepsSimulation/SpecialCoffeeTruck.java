public class SpecialCoffeeTruck extends RegularCoffeeTruck {
    public SpecialCoffeeTruck(String location) {
        super(location);
        // Add 2 extra bins for syrups (total 10 bins)
        StorageBin[] newBins = new StorageBin[10];
        System.arraycopy(storageBins, 0, newBins, 0, 8);
        newBins[8] = new StorageBin();
        newBins[9] = new StorageBin();
        storageBins = newBins;
    }
    
    @Override
    public String getType() {
        return "Special Coffee Truck (JavaJeep+)";
    }
    
    @Override
    public boolean processOrder(CoffeeOrder order) {
        System.out.println("\n>>> Preparing " + order.getSize() + " " + order.getDrinkType() + "...");
        
        double cupSize = order.getCupSize();
        double coffeeNeeded = 0;
        double waterNeeded = 0;
        double milkNeeded = 0;
        double extraCoffee = 0;
        
        int brewRatio;
        String brewType;
        switch (order.getBrewStrength()) {
            case 1: // Light
                brewRatio = 20;
                brewType = "Light";
                break;
            case 3: // Strong
                brewRatio = 15;
                brewType = "Strong";
                break;
            default: // Standard
                brewRatio = 18;
                brewType = "Standard";
                break;
        }
        
        if (order.getDrinkType().equals("Americano")) {
            double espresso = cupSize / 3.0;
            waterNeeded = cupSize - espresso;
            coffeeNeeded = espresso / brewRatio * 28.34952;
        } else if (order.getDrinkType().equals("Latte")) {
            double espresso = cupSize / 5.0;
            milkNeeded = cupSize - espresso;
            coffeeNeeded = espresso / brewRatio * 28.34952;
        } else if (order.getDrinkType().equals("Cappuccino")) {
            double espresso = cupSize / 3.0;
            milkNeeded = cupSize - espresso;
            coffeeNeeded = espresso / brewRatio * 28.34952;
        }
        
        if (order.getExtraShots() > 0) {
            extraCoffee = order.getExtraShots() * (1.0 / brewRatio * 28.34952);
        }
        
        if (!consumeSpecialIngredients(order.getSize(), coffeeNeeded + extraCoffee, waterNeeded, milkNeeded, order.isHasSyrup())) {
            return false;
        }
        
        System.out.println(">>> Brewing " + brewType + " espresso - " + String.format("%.2f", coffeeNeeded) + " grams of coffee...");
        
        if (waterNeeded > 0) {
            System.out.println(">>> Adding Water...");
        }
        if (milkNeeded > 0) {
            System.out.println(">>> Adding Milk...");
        }
        if (order.isHasSyrup()) {
            System.out.println(">>> Adding Syrup...");
        }
        if (order.getExtraShots() > 0) {
            System.out.println(">>> Adding " + order.getExtraShots() + " extra shot(s) of " + brewType + " brew espresso - " + String.format("%.2f", extraCoffee) + " grams of coffee.");
        }
        
        System.out.println(">>> Custom " + order.getDrinkType() + " Done!");
        
        double price = priceList.getPrice(order.getSize() + " " + order.getDrinkType());
        if (order.getExtraShots() > 0) {
            price += order.getExtraShots() * priceList.getPrice("Extra Shot");
        }
        if (order.isHasSyrup()) {
            price += priceList.getPrice("Syrup Add-on");
        }
        
        salesHistory.addTransaction("Custom " + order.getSize() + " " + order.getDrinkType(), coffeeNeeded + extraCoffee, waterNeeded, milkNeeded, order.getExtraShots(), order.isHasSyrup() ? 1 : 0, price);
        
        return true;
    }
    
    private boolean consumeSpecialIngredients(String cupSize, double coffee, double water, double milk, boolean needsSyrup) {
        StorageBin cupBin = null;
        StorageBin coffeeBin = null;
        StorageBin waterBin = null;
        StorageBin milkBin = null;
        StorageBin syrupBin = null;
        
        for (StorageBin bin : storageBins) {
            if (bin.getItem() != null) {
                String itemName = bin.getItem().getName();
                if (itemName.contains(cupSize + " Cup") && bin.getQuantity() > 0) {
                    cupBin = bin;
                } else if (itemName.equals("Coffee Beans") && bin.getQuantity() >= coffee) {
                    coffeeBin = bin;
                } else if (itemName.equals("Water") && bin.getQuantity() >= water) {
                    waterBin = bin;
                } else if (itemName.equals("Milk") && bin.getQuantity() >= milk) {
                    milkBin = bin;
                } else if (needsSyrup && itemName.contains("Syrup") && bin.getQuantity() > 0) {
                    syrupBin = bin;
                }
            }
        }
        
        if (cupBin == null || coffeeBin == null || 
            (water > 0 && waterBin == null) || (milk > 0 && milkBin == null) || (needsSyrup && syrupBin == null)) {
            return false;
        }
        
        cupBin.consume(1);
        coffeeBin.consume(coffee);
        if (water > 0) waterBin.consume(water);
        if (milk > 0) milkBin.consume(milk);
        if (needsSyrup) syrupBin.consume(1.0); // 1 fl oz of syrup
        
        return true;
    }
}