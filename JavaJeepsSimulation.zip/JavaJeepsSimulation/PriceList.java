public class PriceList {
    private static final int MAX_ITEMS = 20;
    private String[] itemNames;
    private double[] prices;
    private int itemCount;
    
    public PriceList() {
        itemNames = new String[MAX_ITEMS];
        prices = new double[MAX_ITEMS];
        itemCount = 0;
    }
    
    public void setPrice(String itemName, double price) {
        for (int i = 0; i < itemCount; i++) {
            if (itemNames[i].equals(itemName)) {
                prices[i] = price;
                return;
            }
        }
        
        if (itemCount < MAX_ITEMS) {
            itemNames[itemCount] = itemName;
            prices[itemCount] = price;
            itemCount++;
        }
    }
    
    public double getPrice(String itemName) {
        for (int i = 0; i < itemCount; i++) {
            if (itemNames[i].equals(itemName)) {
                return prices[i];
            }
        }
        return 0.0;
    }
    
    public void displayMenu() {
        System.out.println("Menu Items:");
        for (int i = 0; i < itemCount; i++) {
            System.out.println(itemNames[i] + ": $" + String.format("%.2f", prices[i]));
        }
    }
}