public abstract class CoffeeTruck {
    protected String location;
    protected StorageBin[] storageBins;
    protected PriceList priceList;
    protected SalesHistory salesHistory;
    
    public CoffeeTruck(String location, int binCount) {
        this.location = location;
        this.storageBins = new StorageBin[binCount];
        for (int i = 0; i < binCount; i++) {
            storageBins[i] = new StorageBin();
        }
        this.priceList = new PriceList();
        this.salesHistory = new SalesHistory();
    }
    
    public abstract String getType();
    public abstract boolean processOrder(CoffeeOrder order);
    
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
    public StorageBin[] getStorageBins() { return storageBins; }
    public PriceList getPriceList() { return priceList; }
    public SalesHistory getSalesHistory() { return salesHistory; }
}