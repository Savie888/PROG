public abstract class Item {
    protected String name;
    protected String unit;
    
    public Item(String name, String unit) { //coffee been, grams
        this.name = name; // (name,unit)
        this.unit = unit;
    }
    
    public String getName() { return name; }
    public String getUnit() { return unit; }
}