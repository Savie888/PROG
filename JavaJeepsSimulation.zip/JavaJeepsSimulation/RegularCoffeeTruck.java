public class RegularCoffeeTruck extends CoffeeTruck {
    public RegularCoffeeTruck(String location) {
        super(location, 8); // 8 storage bins for regular truck
    }
    
    @Override
    public String getType() {
        return "Regular Coffee Truck (JavaJeep)";
    }
    
    @Override
    public boolean processOrder(CoffeeOrder order) {
        System.out.println("\n>>> Preparing " + order.getSize() + " " + order.getDrinkType() + "...");
        
        // Calculate required ingredients
        double cupSize = order.getCupSize();
        double coffeeNeeded = 0;
        double waterNeeded = 0;
        double milkNeeded = 0;
        
        // Calculate espresso requirements (Standard brew ratio 1:18)
        if (order.getDrinkType().equals("Americano")) {
            // 1 part espresso, 2 parts water
            double espresso = cupSize / 3.0;
            waterNeeded = cupSize - espresso;
            coffeeNeeded = espresso / 18.0 * 28.34952; // Convert to grams
        } else if (order.getDrinkType().equals("Latte")) {
            // 1/5 espresso, 4/5 milk
            double espresso = cupSize / 5.0;
            milkNeeded = cupSize - espresso;
            coffeeNeeded = espresso / 18.0 * 28.34952;
        } else if (order.getDrinkType().equals("Cappuccino")) {
            // 1/3 espresso, 2/3 milk
            double espresso = cupSize / 3.0;
            milkNeeded = cupSize - espresso;
            coffeeNeeded = espresso / 18.0 * 28.34952;
        }
        
        if (!consumeIngredients(order.getSize(), coffeeNeeded, waterNeeded, milkNeeded)) {
            return false;
        }
        
        System.out.println(">>> Brewing Standard espresso - " + String.format("%.2f", coffeeNeeded) + " grams of coffee...");
        
        if (waterNeeded > 0) {
            System.out.println(">>> Adding Water...");
        }
        if (milkNeeded > 0) {
            System.out.println(">>> Adding Milk...");
        }
        
        System.out.println(">>> " + order.getDrinkType() + " Done!");
        
        double price = priceList.getPrice(order.getSize() + " " + order.getDrinkType());
        salesHistory.addTransaction(order.getSize() + " " + order.getDrinkType(), 
                                   coffeeNeeded, waterNeeded, milkNeeded, 0, 0, price);
        
        return true;
    }
    
    protected boolean consumeIngredients(String cupSize, double coffee, double water, double milk) {
        StorageBin cupBin = null;
        StorageBin coffeeBin = null;
        StorageBin waterBin = null;
        StorageBin milkBin = null;
        
        for (StorageBin bin : storageBins) {
            if (bin.getItem() != null) {
                String itemName = bin.getItem().getName();
                if (itemName.contains(cupSize + " Cup") && bin.getQuantity() > 0) {
                    cupBin = bin;
                } else if (itemName.equals("Coffee Beans") && bin.getQuantity() >= coffee) {
                    coffeeBin = bin;
                } else if (itemName.equals("Water") && bin.getQuantity() >= water) {
                    waterBin = bin;
                } else if (itemName.equals("Milk") && bin.getQuantity() >= milk) {
                    milkBin = bin;
                }
            }
        }
        
        if (cupBin == null || coffeeBin == null || 
            (water > 0 && waterBin == null) || (milk > 0 && milkBin == null)) {
            return false;
        }
        
        cupBin.consume(1);
        coffeeBin.consume(coffee);
        if (water > 0) waterBin.consume(water);
        if (milk > 0) milkBin.consume(milk);
        
        return true;
    }
}