public class Transaction {
    private String drinkName;
    private double coffeeUsed;
    private double waterUsed;
    private double milkUsed;
    private int extraShots;
    private int syrups;
    private double price;
    
    public Transaction(String drinkName, double coffeeUsed, double waterUsed, double milkUsed,
                      int extraShots, int syrups, double price) {
        this.drinkName = drinkName;
        this.coffeeUsed = coffeeUsed;
        this.waterUsed = waterUsed;
        this.milkUsed = milkUsed;
        this.extraShots = extraShots;
        this.syrups = syrups;
        this.price = price;
    }
    
    public String getDrinkName() { return drinkName; }
    public double getCoffeeUsed() { return coffeeUsed; }
    public double getWaterUsed() { return waterUsed; }
    public double getMilkUsed() { return milkUsed; }
    public int getExtraShots() { return extraShots; }
    public int getSyrups() { return syrups; }
    public double getPrice() { return price; }
}