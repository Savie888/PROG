public class StorageBin {
    private Item item;
    private double quantity;
    private double capacity;
    
    public StorageBin() {
        this.item = null;
        this.quantity = 0;
        this.capacity = 0;
    }
    
    public boolean addItem(Item item, double quantity) {
        if (this.item == null || this.item.getName().equals(item.getName())) {
            this.item = item;
            setCapacityBasedOnItem();
            if (this.quantity + quantity <= capacity) {
                this.quantity += quantity;
                return true;
            }
        }
        return false;
    }
    
    public void replaceContents(Item newItem, double quantity) {
        this.item = newItem;
        setCapacityBasedOnItem();
        this.quantity = Math.min(quantity, capacity);
    }
    
    public void addQuantity(double amount) {
        if (item != null) {
            quantity = Math.min(quantity + amount, capacity);
        }
    }
    
    public boolean consume(double amount) {
        if (quantity >= amount) {
            quantity -= amount;
            return true;
        }
        return false;
    }
    
    public void empty() {
        this.item = null;
        this.quantity = 0;
        this.capacity = 0;
    }
    
    private void setCapacityBasedOnItem() {
        if (item != null) {
            String itemName = item.getName();
            if (itemName.contains("Small Cup")) {
                capacity = 80;
            } else if (itemName.contains("Medium Cup")) {
                capacity = 64;
            } else if (itemName.contains("Large Cup")) {
                capacity = 40;
            } else if (itemName.equals("Coffee Beans")) {
                capacity = 1008;
            } else if (itemName.equals("Milk") || itemName.equals("Water") || itemName.contains("Syrup")) {
                capacity = 640;
            }
        }
    }
    
    public String getContents() {
        if (item == null) {
            return "Empty";
        }
        return item.getName() + " - " + quantity + "/" + capacity + " " + item.getUnit();
    }
    
    public Item getItem() { return item; }
    public double getQuantity() { return quantity; }
    public double getCapacity() { return capacity; }
}