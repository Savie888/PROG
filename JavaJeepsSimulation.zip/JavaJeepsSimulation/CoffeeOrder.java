public class CoffeeOrder {
    private String drinkType;
    private String size;
    private double cupSize;
    private int brewStrength; // 1=Light 2=Standard 3=Strong
    private int extraShots;
    private boolean hasSyrup;
    
    public CoffeeOrder(String drinkType, String size, double cupSize) {
        this.drinkType = drinkType;
        this.size = size;
        this.cupSize = cupSize;
        this.brewStrength = 2; 
        this.extraShots = 0;
        this.hasSyrup = false;
    }
    
    public String getDrinkType() { return drinkType; }
    public String getSize() { return size; }
    public double getCupSize() { return cupSize; }
    public int getBrewStrength() { return brewStrength; }
    public void setBrewStrength(int brewStrength) { this.brewStrength = brewStrength; }
    public int getExtraShots() { return extraShots; }
    public void setExtraShots(int extraShots) { this.extraShots = extraShots; }
    public boolean isHasSyrup() { return hasSyrup; }
    public void setHasSyrup(boolean hasSyrup) { this.hasSyrup = hasSyrup; }
}