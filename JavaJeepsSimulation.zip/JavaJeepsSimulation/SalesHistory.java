public class SalesHistory {
    private static final int MAX_TRANSACTIONS = 100;
    private Transaction[] transactions;
    private int transactionCount;
    private double totalSales;
    
    public SalesHistory() {
        transactions = new Transaction[MAX_TRANSACTIONS];
        transactionCount = 0;
        totalSales = 0.0;
    }
    
    public void addTransaction(String drinkName, double coffee, double water, double milk, 
                              int extraShots, int syrups, double price) {
        if (transactionCount < MAX_TRANSACTIONS) {
            transactions[transactionCount] = new Transaction(drinkName, coffee, water, milk, 
                                                           extraShots, syrups, price);
            transactionCount++;
            totalSales += price;
        }
    }
    
    public void displayTransactions() {
        if (transactionCount == 0) {
            System.out.println("No transactions recorded.");
            return;
        }
        
        System.out.println("Recent Transactions:");
        for (int i = 0; i < transactionCount; i++) {
            Transaction t = transactions[i];
            System.out.println((i + 1) + ". " + t.getDrinkName() + 
                              " - Coffee: " + String.format("%.2f", t.getCoffeeUsed()) + "g" +
                              ", Water: " + String.format("%.2f", t.getWaterUsed()) + " fl oz" +
                              ", Milk: " + String.format("%.2f", t.getMilkUsed()) + " fl oz" +
                              (t.getExtraShots() > 0 ? ", Extra Shots: " + t.getExtraShots() : "") +
                              (t.getSyrups() > 0 ? ", Syrups: " + t.getSyrups() : "") +
                              " - $" + String.format("%.2f", t.getPrice()));
        }
        System.out.println("Total Sales: $" + String.format("%.2f", totalSales));
    }
    
    public double getTotalSales() { return totalSales; }
    public int getTransactionCount() { return transactionCount; }
}