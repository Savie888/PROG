public class Cup extends Item {
    private double capacity;
    
    public Cup(String size, double capacity) {
        super(size + " Cup", "pcs");
        this.capacity = capacity;
    }
    
    public double getCapacity() { return capacity; }
}